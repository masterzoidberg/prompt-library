# Prompt Library

A personal, single-user, browser-based library for storing, organizing, finding, and copying reusable AI prompts. All data lives locally in IndexedDB.

See [`Design.md`](./Design.md) for the full specification.

## Commands

```bash
npm install
npm run dev          # Vite dev server
npm run build        # Production build
npm run preview      # Preview production build
npm run lint         # Lint (oxlint)
npm run test         # Run tests once
npm run test:watch   # Watch tests
```

## Stack

- React 19 + TypeScript 5 (strict)
- Vite 8
- Tailwind CSS 3
- IndexedDB via `idb`
- Radix UI primitives, lucide-react icons, sonner toasts
- Vitest + Testing Library + fake-indexeddb for tests