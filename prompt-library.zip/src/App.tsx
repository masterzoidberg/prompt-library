import { useEffect, useState } from 'react';
import { AppShell } from './components/layout/AppShell';
import { AppStateProvider } from './hooks/AppStateProvider';
import { LibraryDataProvider } from './hooks/LibraryDataProvider';
import { ensureSeeded } from './data/db';
import { PromptList } from './components/prompts/PromptList';
import { DialogRouter } from './components/prompts/DialogRouter';

export default function App() {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    ensureSeeded()
      .catch(() => undefined)
      .finally(() => setReady(true));
  }, []);

  if (!ready) {
    return (
      <div className="flex h-screen items-center justify-center bg-neutral-50 dark:bg-neutral-950">
        <p className="text-sm text-neutral-500">Loading…</p>
      </div>
    );
  }

  return (
    <LibraryDataProvider>
      <AppStateProvider>
        <AppShell>
          <PromptList />
        </AppShell>
        <DialogRouter />
      </AppStateProvider>
    </LibraryDataProvider>
  );
}