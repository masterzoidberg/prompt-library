import { useState, useCallback, useRef } from 'react';
import { Sidebar } from './Sidebar';
import { TopBar } from './TopBar';
import { MobileSidebar } from './MobileSidebar';
import { useKeyboardShortcuts } from '../../hooks/useKeyboardShortcuts';
import { useApplyTheme } from '../../hooks/useTheme';
import { useSettings } from '../../hooks/useSettings';

interface AppShellProps {
  children: React.ReactNode;
}

export function AppShell({ children }: AppShellProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const searchRef = useRef<HTMLInputElement | null>(null);

  const { settings } = useSettings();
  useApplyTheme(settings?.theme);

  const focusSearch = useCallback(() => {
    const inputs = document.querySelectorAll<HTMLInputElement>('input[type="search"]');
    const el = inputs[0] ?? null;
    if (el) {
      el.focus();
      el.select();
    }
    searchRef.current = el;
  }, []);

  useKeyboardShortcuts({ focusSearch });

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-neutral-50 text-neutral-900 dark:bg-neutral-950 dark:text-neutral-100">
      <div className="hidden lg:flex">
        <Sidebar />
      </div>
      <MobileSidebar open={mobileOpen} onClose={() => setMobileOpen(false)}>
        <Sidebar />
      </MobileSidebar>
      <div className="flex min-w-0 flex-1 flex-col">
        <TopBar onToggleSidebar={() => setMobileOpen(true)} />
        <main className="flex-1 overflow-y-auto scrollbar-thin" id="main">
          {children}
        </main>
      </div>
    </div>
  );
}