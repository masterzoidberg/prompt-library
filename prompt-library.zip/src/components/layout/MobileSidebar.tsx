import type { ReactNode } from 'react';
import { X } from 'lucide-react';
import { Button } from '../common/Button';

interface MobileSidebarProps {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
}

export function MobileSidebar({ open, onClose, children }: MobileSidebarProps) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40 lg:hidden" role="dialog" aria-modal="true">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="absolute inset-y-0 left-0 flex w-72 max-w-[80vw] flex-col bg-neutral-50 shadow-xl dark:bg-neutral-950">
        <div className="absolute right-2 top-2">
          <Button size="icon" variant="ghost" aria-label="Close navigation" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>
        {children}
      </div>
    </div>
  );
}