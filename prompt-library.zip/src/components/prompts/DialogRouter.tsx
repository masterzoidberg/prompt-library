import { useAppState } from '../../hooks/useAppState';
import { usePrompts } from '../../hooks/usePrompts';
import { useFolders } from '../../hooks/useFolders';
import { useTags } from '../../hooks/useTags';
import { PromptFormDialog } from './PromptFormDialog';
import { ConfirmDeleteDialog } from './ConfirmDeleteDialog';
import { MoveToFolderDialog } from './MoveToFolderDialog';
import { notify } from '../common/Toast';
import { SYSTEM_FOLDER_ID } from '../../config/constants';
import * as folderRepo from '../../data/folderRepository';
import * as tagRepo from '../../data/tagRepository';
import { Dialog } from '../common/Dialog';
import { Button } from '../common/Button';
import { Input } from '../common/Input';
import { useState } from 'react';
import { SettingsDialog } from '../settings/SettingsDialog';

export function DialogRouter() {
  const { dialog, setDialog } = useAppState();
  const { prompts, create, update, remove } = usePrompts();
  const { folders, create: createFolder, update: updateFolder, remove: removeFolder } = useFolders();
  const { tags, create: createTag, update: updateTag, remove: removeTag } = useTags();

  const open = dialog.kind !== 'none';
  const close = () => setDialog({ kind: 'none' });

  switch (dialog.kind) {
    case 'new-prompt':
      return (
        <PromptFormDialog
          open={open}
          onOpenChange={(o) => (o ? null : close())}
          onSubmit={async (values) => {
            await create(values as Parameters<typeof create>[0]);
            notify.success('Prompt created');
          }}
        />
      );
    case 'edit-prompt': {
      const prompt = prompts.find((p) => p.id === dialog.promptId);
      if (!prompt) return null;
      return (
        <PromptFormDialog
          open={open}
          onOpenChange={(o) => (o ? null : close())}
          initial={prompt}
          onSubmit={async (values) => {
            await update(prompt.id, values);
            notify.success('Prompt updated');
          }}
        />
      );
    }
    case 'delete-prompt': {
      const prompt = prompts.find((p) => p.id === dialog.promptId);
      if (!prompt) return null;
      return (
        <ConfirmDeleteDialog
          open={open}
          onOpenChange={(o) => (o ? null : close())}
          title="Delete prompt?"
          description={<>“{prompt.title}” will be permanently deleted.</>}
          onConfirm={async () => {
            await remove(prompt.id);
            notify.success('Prompt deleted');
          }}
        />
      );
    }
    case 'move-prompt': {
      const prompt = prompts.find((p) => p.id === dialog.promptId);
      if (!prompt) return null;
      return (
        <MoveToFolderDialog
          open={open}
          onOpenChange={(o) => (o ? null : close())}
          currentFolderId={prompt.folderId}
          onMove={async (folderId) => {
            const target = folderId || SYSTEM_FOLDER_ID;
            await update(prompt.id, { folderId: target });
            const f = folders.find((x) => x.id === target);
            notify.success(`Moved to ${f?.name ?? 'Unfiled'}`);
          }}
        />
      );
    }
    case 'new-folder':
      return (
        <NameDialog
          open={open}
          onOpenChange={(o) => (o ? null : close())}
          title="New folder"
          label="Folder name"
          onSubmit={async (name) => {
            try {
              await createFolder({ name });
              notify.success('Folder created');
            } catch (err) {
              if (err instanceof folderRepo.FolderNameConflictError)
                throw new Error('A folder with that name already exists.');
              throw err;
            }
          }}
        />
      );
    case 'rename-folder': {
      const folder = folders.find((f) => f.id === dialog.folderId);
      if (!folder) return null;
      return (
        <NameDialog
          open={open}
          onOpenChange={(o) => (o ? null : close())}
          title="Rename folder"
          label="Folder name"
          initial={folder.name}
          onSubmit={async (name) => {
            try {
              await updateFolder(folder.id, { name });
              notify.success('Folder renamed');
            } catch (err) {
              if (err instanceof folderRepo.FolderNameConflictError)
                throw new Error('A folder with that name already exists.');
              throw err;
            }
          }}
        />
      );
    }
    case 'delete-folder': {
      const folder = folders.find((f) => f.id === dialog.folderId);
      if (!folder) return null;
      return (
        <ConfirmDeleteDialog
          open={open}
          onOpenChange={(o) => (o ? null : close())}
          title="Delete folder?"
          description={
            <>
              “{folder.name}” will be deleted. Prompts in this folder will move to{' '}
              <strong>Unfiled</strong>.
            </>
          }
          onConfirm={async () => {
            await removeFolder(folder.id);
            notify.success('Folder deleted');
          }}
        />
      );
    }
    case 'new-tag':
      return (
        <NameDialog
          open={open}
          onOpenChange={(o) => (o ? null : close())}
          title="New tag"
          label="Tag name"
          onSubmit={async (name) => {
            try {
              await createTag({ name });
              notify.success('Tag created');
            } catch (err) {
              if (err instanceof tagRepo.TagNameConflictError)
                throw new Error('A tag with that name already exists.');
              throw err;
            }
          }}
        />
      );
    case 'rename-tag': {
      const tag = tags.find((t) => t.id === dialog.tagId);
      if (!tag) return null;
      return (
        <NameDialog
          open={open}
          onOpenChange={(o) => (o ? null : close())}
          title="Rename tag"
          label="Tag name"
          initial={tag.name}
          onSubmit={async (name) => {
            try {
              await updateTag(tag.id, { name });
              notify.success('Tag renamed');
            } catch (err) {
              if (err instanceof tagRepo.TagNameConflictError)
                throw new Error('A tag with that name already exists.');
              throw err;
            }
          }}
        />
      );
    }
    case 'delete-tag': {
      const tag = tags.find((t) => t.id === dialog.tagId);
      if (!tag) return null;
      return (
        <ConfirmDeleteDialog
          open={open}
          onOpenChange={(o) => (o ? null : close())}
          title="Delete tag?"
          description={
            <>“#{tag.name}” will be removed from any prompts that use it.</>
          }
          onConfirm={async () => {
            await removeTag(tag.id);
            notify.success('Tag deleted');
          }}
        />
      );
    }
    case 'settings':
      return <SettingsDialog open={open} onOpenChange={(o) => (o ? null : close())} />;
    default:
      return null;
  }
}

interface NameDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  label: string;
  initial?: string;
  onSubmit: (name: string) => Promise<void>;
}

function NameDialog({ open, onOpenChange, title, label, initial = '', onSubmit }: NameDialogProps) {
  const [name, setName] = useState(initial);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!name.trim()) {
      setError('Name is required.');
      return;
    }
    setError(null);
    setBusy(true);
    try {
      await onSubmit(name.trim());
      setName('');
      onOpenChange(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange} title={title}>
      <form onSubmit={submit} className="space-y-3">
        <label className="block text-sm font-medium">
          {label}
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            autoFocus
            className="mt-1"
          />
        </label>
        {error ? <p className="text-sm text-red-600">{error}</p> : null}
        <div className="flex justify-end gap-2 pt-1">
          <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button type="submit" variant="primary" disabled={busy}>
            {busy ? 'Saving…' : 'Save'}
          </Button>
        </div>
      </form>
    </Dialog>
  );
}