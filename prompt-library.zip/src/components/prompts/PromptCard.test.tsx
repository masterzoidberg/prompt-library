import { describe, it, expect, vi, beforeEach } from 'vitest';
import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import 'fake-indexeddb/auto';
import { PromptCard } from './PromptCard';
import type { Prompt, Folder, Tag } from '../../types';

const folder: Folder = {
  id: 'f1',
  name: 'Writing',
  normalizedName: 'writing',
  createdAt: '2025-01-01T00:00:00.000Z',
  updatedAt: '2025-01-01T00:00:00.000Z',
};

const tags: Tag[] = [
  { id: 't1', name: 'code', normalizedName: 'code', createdAt: '', updatedAt: '' },
];

const prompt: Prompt = {
  id: 'p1',
  title: 'Hello',
  content: 'line1\nline2',
  description: 'desc',
  folderId: 'f1',
  tagIds: ['t1'],
  isFavorite: false,
  copyCount: 0,
  createdAt: '2025-01-01T00:00:00.000Z',
  updatedAt: '2025-01-01T00:00:00.000Z',
  lastCopiedAt: null,
};

describe('PromptCard', () => {
  beforeEach(() => {
    Object.assign(navigator, {
      clipboard: { writeText: vi.fn().mockResolvedValue(undefined) },
    });
  });

  it('renders title and preview', () => {
    render(
      <PromptCard
        prompt={prompt}
        folder={folder}
        tags={tags}
        onCopy={vi.fn()}
        onEdit={vi.fn()}
        onDuplicate={vi.fn()}
        onDelete={vi.fn()}
        onMove={vi.fn()}
        onToggleFavorite={vi.fn()}
      />,
    );
    expect(screen.getByText('Hello')).toBeInTheDocument();
    expect(screen.getByText(/line1/)).toBeInTheDocument();
  });

  it('copies exact content on card click and calls onCopy', async () => {
    const onCopy = vi.fn();
    render(
      <PromptCard
        prompt={prompt}
        folder={folder}
        tags={tags}
        onCopy={onCopy}
        onEdit={vi.fn()}
        onDuplicate={vi.fn()}
        onDelete={vi.fn()}
        onMove={vi.fn()}
        onToggleFavorite={vi.fn()}
      />,
    );
    const card = screen.getByRole('button', { name: /copy prompt: hello/i });
    fireEvent.click(card);
    await waitFor(() => {
      expect(navigator.clipboard.writeText).toHaveBeenCalledWith('line1\nline2');
      expect(onCopy).toHaveBeenCalledWith('p1');
    });
  });

  it('does not copy when an inner button is clicked (stopPropagation)', () => {
    const onCopy = vi.fn();
    render(
      <PromptCard
        prompt={prompt}
        folder={folder}
        tags={tags}
        onCopy={onCopy}
        onEdit={vi.fn()}
        onDuplicate={vi.fn()}
        onDelete={vi.fn()}
        onMove={vi.fn()}
        onToggleFavorite={vi.fn()}
      />,
    );
    fireEvent.click(screen.getByRole('button', { name: /add to favorites/i }));
    expect(navigator.clipboard.writeText).not.toHaveBeenCalled();
    expect(onCopy).not.toHaveBeenCalled();
  });
});