import { useState } from 'react';
import { Copy, Check, MoreHorizontal, Star, Pencil, Trash2, Files, FolderInput } from 'lucide-react';
import type { Prompt, Folder, Tag } from '../../types';
import { Button } from '../common/Button';
import { Dropdown, DropdownItem } from '../common/Dropdown';
import { formatRelative } from '../../utils/dateFormat';

interface PromptCardProps {
  prompt: Prompt;
  folder?: Folder;
  tags: Tag[];
  onCopy: (id: string) => void;
  onEdit: (id: string) => void;
  onDuplicate: (id: string) => void;
  onDelete: (id: string) => void;
  onMove: (id: string) => void;
  onToggleFavorite: (id: string, value: boolean) => void;
}

export function PromptCard({
  prompt,
  folder,
  tags,
  onCopy,
  onEdit,
  onDuplicate,
  onDelete,
  onMove,
  onToggleFavorite,
}: PromptCardProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(prompt.content);
      onCopy(prompt.id);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1500);
    } catch {
      // Fall through silently; UI handles via toast in container if needed.
    }
  };

  const stop = (e: React.MouseEvent) => e.stopPropagation();

  return (
    <article
      role="button"
      tabIndex={0}
      aria-label={`Copy prompt: ${prompt.title}`}
      onClick={handleCopy}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          handleCopy();
        }
      }}
      className="group relative flex h-full cursor-pointer flex-col gap-3 rounded-lg border border-neutral-200 bg-white p-4 transition-colors hover:border-accent-400 focus:border-accent-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-accent-500 dark:border-neutral-800 dark:bg-neutral-900 dark:hover:border-accent-500"
    >
      <header className="flex items-start gap-2">
        <h3 className="flex-1 truncate text-base font-semibold text-neutral-900 dark:text-neutral-100">
          {prompt.title}
        </h3>
        <button
          type="button"
          aria-label={prompt.isFavorite ? 'Remove from favorites' : 'Add to favorites'}
          aria-pressed={prompt.isFavorite}
          onClick={(e) => {
            stop(e);
            onToggleFavorite(prompt.id, !prompt.isFavorite);
          }}
          className="rounded-md p-1 text-neutral-400 hover:text-yellow-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-accent-500"
        >
          <Star
            className={`h-4 w-4 ${prompt.isFavorite ? 'fill-yellow-400 text-yellow-500' : ''}`}
          />
        </button>
        <Dropdown
          trigger={
            <button
              type="button"
              aria-label="Prompt actions"
              onClick={stop}
              className="rounded-md p-1 text-neutral-500 hover:bg-neutral-100 dark:hover:bg-neutral-800"
            >
              <MoreHorizontal className="h-4 w-4" />
            </button>
          }
        >
          <DropdownItem onSelect={() => onEdit(prompt.id)}>
            <Pencil className="h-4 w-4" /> Edit
          </DropdownItem>
          <DropdownItem onSelect={() => onDuplicate(prompt.id)}>
            <Files className="h-4 w-4" /> Duplicate
          </DropdownItem>
          <DropdownItem onSelect={() => onMove(prompt.id)}>
            <FolderInput className="h-4 w-4" /> Move to folder
          </DropdownItem>
          <DropdownItem onSelect={() => onToggleFavorite(prompt.id, !prompt.isFavorite)}>
            <Star className="h-4 w-4" /> {prompt.isFavorite ? 'Unfavorite' : 'Favorite'}
          </DropdownItem>
          <DropdownItem onSelect={() => onDelete(prompt.id)} destructive>
            <Trash2 className="h-4 w-4" /> Delete
          </DropdownItem>
        </Dropdown>
      </header>

      <pre className="line-clamp-4 whitespace-pre-wrap break-words font-mono text-xs text-neutral-600 dark:text-neutral-300">
        {prompt.content}
      </pre>

      {prompt.description ? (
        <p className="line-clamp-2 text-xs text-neutral-500 dark:text-neutral-400">
          {prompt.description}
        </p>
      ) : null}

      <footer className="mt-auto flex items-center justify-between gap-2 text-xs text-neutral-500">
        <div className="flex flex-1 flex-wrap items-center gap-1 overflow-hidden">
          {folder ? (
            <span className="rounded bg-neutral-100 px-1.5 py-0.5 dark:bg-neutral-800">
              {folder.name}
            </span>
          ) : null}
          {tags.slice(0, 3).map((t) => (
            <span
              key={t.id}
              className="rounded bg-accent-50 px-1.5 py-0.5 text-accent-700 dark:bg-accent-900/30 dark:text-accent-200"
            >
              #{t.name}
            </span>
          ))}
          {tags.length > 3 ? (
            <span className="rounded bg-neutral-100 px-1.5 py-0.5 dark:bg-neutral-800">
              +{tags.length - 3}
            </span>
          ) : null}
        </div>
        <span className="shrink-0">{formatRelative(prompt.updatedAt)}</span>
        <Button
          variant="ghost"
          size="icon"
          aria-label="Copy prompt"
          onClick={(e) => {
            stop(e);
            handleCopy();
          }}
          className="h-7 w-7"
        >
          {copied ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
        </Button>
      </footer>
    </article>
  );
}