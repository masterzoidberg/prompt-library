import { useEffect, useState } from 'react';
import { Dialog } from '../common/Dialog';
import { Button } from '../common/Button';
import { Input } from '../common/Input';
import { Textarea } from '../common/Textarea';
import { useFolders } from '../../hooks/useFolders';
import { useTags } from '../../hooks/useTags';
import { SYSTEM_FOLDER_ID } from '../../config/constants';
import { confirmDiscard, useUnsavedGuard } from '../../hooks/useUnsavedGuard';
import type { Prompt } from '../../types';
import type { PromptCreate, PromptUpdate } from '../../types/prompt';

interface PromptFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initial?: Prompt;
  onSubmit: (values: PromptCreate | PromptUpdate) => Promise<void> | void;
}

export function PromptFormDialog({ open, onOpenChange, initial, onSubmit }: PromptFormDialogProps) {
  const { folders } = useFolders();
  const { tags } = useTags();
  const [title, setTitle] = useState(initial?.title ?? '');
  const [content, setContent] = useState(initial?.content ?? '');
  const [description, setDescription] = useState(initial?.description ?? '');
  const [folderId, setFolderId] = useState(initial?.folderId ?? SYSTEM_FOLDER_ID);
  const [tagIds, setTagIds] = useState<string[]>(initial?.tagIds ?? []);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (open) {
      setTitle(initial?.title ?? '');
      setContent(initial?.content ?? '');
      setDescription(initial?.description ?? '');
      setFolderId(initial?.folderId ?? SYSTEM_FOLDER_ID);
      setTagIds(initial?.tagIds ?? []);
      setError(null);
      setSubmitting(false);
    }
  }, [open, initial]);

  const dirty =
    title !== (initial?.title ?? '') ||
    content !== (initial?.content ?? '') ||
    description !== (initial?.description ?? '') ||
    folderId !== (initial?.folderId ?? SYSTEM_FOLDER_ID) ||
    tagIds.join(',') !== (initial?.tagIds ?? []).join(',');

  useUnsavedGuard(dirty);

  const handleClose = (next: boolean) => {
    if (!next && dirty) {
      if (!confirmDiscard()) return;
    }
    onOpenChange(next);
  };

  const handleSubmit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    setError(null);
    if (!title.trim()) return setError('Title is required.');
    if (!content.trim()) return setError('Content is required.');
    setSubmitting(true);
    try {
      await onSubmit({
        title: title.trim(),
        content,
        description: description.trim() || undefined,
        folderId,
        tagIds,
      });
      onOpenChange(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      handleSubmit();
    }
  };

  const toggleTag = (id: string) =>
    setTagIds((prev) => (prev.includes(id) ? prev.filter((t) => t !== id) : [...prev, id]));

  return (
    <Dialog
      open={open}
      onOpenChange={handleClose}
      title={initial ? 'Edit prompt' : 'New prompt'}
      description={initial ? 'Update your prompt details.' : 'Create a reusable AI prompt.'}
      maxWidthClass="max-w-2xl"
    >
      <form onSubmit={handleSubmit} onKeyDown={handleKeyDown} className="space-y-4">
        <div>
          <label htmlFor="prompt-title" className="mb-1 block text-sm font-medium">
            Title
          </label>
          <Input
            id="prompt-title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. Explain code like I'm five"
            autoFocus
            data-autofocus-safe="true"
          />
        </div>

        <div>
          <label htmlFor="prompt-content" className="mb-1 block text-sm font-medium">
            Content
          </label>
          <Textarea
            id="prompt-content"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Paste or write your prompt. Formatting is preserved exactly."
            rows={10}
          />
        </div>

        <div>
          <label htmlFor="prompt-description" className="mb-1 block text-sm font-medium">
            Description <span className="text-neutral-400">(optional)</span>
          </label>
          <Input
            id="prompt-description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Short note about when to use this"
          />
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="prompt-folder" className="mb-1 block text-sm font-medium">
              Folder
            </label>
            <select
              id="prompt-folder"
              value={folderId}
              onChange={(e) => setFolderId(e.target.value)}
              className="h-10 w-full rounded-md border border-neutral-300 bg-white px-3 text-sm dark:border-neutral-700 dark:bg-neutral-900"
            >
              {folders.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <span className="mb-1 block text-sm font-medium">Tags</span>
            <div className="flex flex-wrap gap-1 rounded-md border border-neutral-300 p-2 dark:border-neutral-700">
              {tags.length === 0 ? (
                <span className="text-xs text-neutral-500">No tags yet.</span>
              ) : (
                tags.map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => toggleTag(t.id)}
                    className={`rounded px-2 py-0.5 text-xs ${
                      tagIds.includes(t.id)
                        ? 'bg-accent-600 text-white'
                        : 'bg-neutral-100 text-neutral-700 dark:bg-neutral-800 dark:text-neutral-200'
                    }`}
                  >
                    #{t.name}
                  </button>
                ))
              )}
            </div>
          </div>
        </div>

        {error ? <p className="text-sm text-red-600 dark:text-red-400">{error}</p> : null}

        <div className="flex items-center justify-end gap-2 pt-2">
          <Button type="button" variant="ghost" onClick={() => handleClose(false)}>
            Cancel
          </Button>
          <Button type="submit" variant="primary" disabled={submitting}>
            {submitting ? 'Saving…' : 'Save'}
          </Button>
        </div>
        <p className="text-xs text-neutral-400">Tip: Ctrl/⌘ + Enter to save.</p>
      </form>
    </Dialog>
  );
}