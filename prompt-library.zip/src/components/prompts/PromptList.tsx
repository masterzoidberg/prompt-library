import { useMemo } from 'react';
import { useAppState } from '../../hooks/useAppState';
import { usePrompts } from '../../hooks/usePrompts';
import { useFolders } from '../../hooks/useFolders';
import { useTags } from '../../hooks/useTags';
import { useSettings } from '../../hooks/useSettings';
import { PromptCard } from './PromptCard';
import { EmptyState } from './EmptyState';
import { searchPrompts } from '../../utils/search';
import { sortPrompts } from '../../utils/sort';
import { notify } from '../common/Toast';
import { copyToClipboard } from '../../utils/copy';

export function PromptList() {
  const { view, selectedTagIds, setDialog } = useAppState();
  const { prompts, copy, update, duplicate } = usePrompts();
  const { folders } = useFolders();
  const { tags } = useTags();
  const { settings } = useSettings();

  const folderMap = useMemo(() => new Map(folders.map((f) => [f.id, f])), [folders]);
  const tagMap = useMemo(() => new Map(tags.map((t) => [t.id, t])), [tags]);

  const visible = useMemo(() => {
    let list = prompts;
    if (view.kind === 'favorites') list = list.filter((p) => p.isFavorite);
    else if (view.kind === 'folder') list = list.filter((p) => p.folderId === view.folderId);
    else if (view.kind === 'tag') list = list.filter((p) => p.tagIds.includes(view.tagId));
    else if (view.kind === 'search') list = searchPrompts(list, view.query, folderMap, tagMap);

    if (selectedTagIds.length > 0) {
      list = list.filter((p) => selectedTagIds.every((t) => p.tagIds.includes(t)));
    }

    if (settings) list = sortPrompts(list, settings.defaultSort);
    return list;
  }, [prompts, view, selectedTagIds, folderMap, tagMap, settings]);

  const handleCopy = async (id: string) => {
    const prompt = prompts.find((p) => p.id === id);
    if (!prompt) return;
    try {
      await copyToClipboard(prompt.content);
      await copy(id);
      notify.success('Copied to clipboard');
    } catch {
      notify.error('Failed to copy');
    }
  };

  if (visible.length === 0) {
    return (
      <EmptyState
        title="No prompts yet"
        description="Create your first prompt to start building your library."
        actionLabel="New prompt"
        onAction={() => setDialog({ kind: 'new-prompt' })}
      />
    );
  }

  return (
    <div className="grid grid-cols-1 gap-4 p-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {visible.map((p) => (
        <PromptCard
          key={p.id}
          prompt={p}
          folder={folderMap.get(p.folderId)}
          tags={p.tagIds.map((id) => tagMap.get(id)).filter((t): t is NonNullable<typeof t> => Boolean(t))}
          onCopy={handleCopy}
          onEdit={(id) => setDialog({ kind: 'edit-prompt', promptId: id })}
          onDuplicate={async (id) => {
            await duplicate(id);
            notify.success('Prompt duplicated');
          }}
          onDelete={(id) => setDialog({ kind: 'delete-prompt', promptId: id })}
          onMove={(id) => setDialog({ kind: 'move-prompt', promptId: id })}
          onToggleFavorite={async (id, value) => {
            await update(id, { isFavorite: value });
          }}
        />
      ))}
    </div>
  );
}