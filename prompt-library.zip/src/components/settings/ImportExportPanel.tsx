import { useRef } from 'react';
import { Download, Upload } from 'lucide-react';
import { Button } from '../common/Button';
import {
  downloadJson,
  exportLibrary,
  importLibrary,
  validateExport,
  ImportValidationError,
} from '../../data/importExport';
import { exportFilename } from '../../data/importExport';
import { notify } from '../common/Toast';
import { usePrompts } from '../../hooks/usePrompts';
import { useFolders } from '../../hooks/useFolders';
import { useTags } from '../../hooks/useTags';
import { useSettings } from '../../hooks/useSettings';

export function ImportExportPanel() {
  const fileRef = useRef<HTMLInputElement>(null);
  const { reload: reloadPrompts } = usePrompts();
  const { reload: reloadFolders } = useFolders();
  const { reload: reloadTags } = useTags();
  const { reload: reloadSettings } = useSettings();

  const handleExport = async () => {
    try {
      const payload = await exportLibrary();
      downloadJson(payload, exportFilename());
      notify.success('Backup downloaded');
    } catch {
      notify.error('Export failed');
    }
  };

  const handleImport = async (file: File) => {
    try {
      const text = await file.text();
      const raw = JSON.parse(text);
      const payload = validateExport(raw);
      if (
        !window.confirm(
          'Importing will replace ALL current prompts, folders, tags, and settings. This cannot be undone. Continue?',
        )
      )
        return;
      await importLibrary(payload);
      await Promise.all([reloadPrompts(), reloadFolders(), reloadTags(), reloadSettings()]);
      notify.success('Library imported');
    } catch (err) {
      if (err instanceof ImportValidationError) notify.error(`Invalid file: ${err.message}`);
      else notify.error('Import failed');
    } finally {
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  return (
    <div className="space-y-2 rounded-md border border-neutral-200 p-3 dark:border-neutral-800">
      <h3 className="text-sm font-semibold">Backup</h3>
      <p className="text-xs text-neutral-500">
        Export your entire library to a JSON file, or import a backup to replace the current library.
      </p>
      <div className="flex flex-wrap gap-2">
        <Button onClick={handleExport}>
          <Download className="h-4 w-4" /> Export
        </Button>
        <Button onClick={() => fileRef.current?.click()}>
          <Upload className="h-4 w-4" /> Import
        </Button>
        <input
          ref={fileRef}
          type="file"
          accept="application/json,.json"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) void handleImport(f);
          }}
        />
      </div>
    </div>
  );
}