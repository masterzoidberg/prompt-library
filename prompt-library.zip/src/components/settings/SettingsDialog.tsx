import { useState } from 'react';
import { Dialog } from '../common/Dialog';
import { Button } from '../common/Button';
import { useSettings } from '../../hooks/useSettings';
import { notify } from '../common/Toast';
import { ImportExportPanel } from './ImportExportPanel';

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function SettingsDialog({ open, onOpenChange }: SettingsDialogProps) {
  const { settings, update } = useSettings();
  const [theme, setTheme] = useState(settings?.theme ?? 'system');
  const [sort, setSort] = useState(settings?.defaultSort ?? 'recently-updated');
  const [confirmDelete, setConfirmDelete] = useState(settings?.confirmBeforeDelete ?? true);

  if (!settings) return null;

  const handleSave = async () => {
    await update({
      theme,
      defaultSort: sort,
      confirmBeforeDelete: confirmDelete,
    });
    notify.success('Settings saved');
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange} title="Settings">
      <div className="space-y-4">
        <div>
          <label htmlFor="settings-theme" className="mb-1 block text-sm font-medium">
            Theme
          </label>
          <select
            id="settings-theme"
            value={theme}
            onChange={(e) => setTheme(e.target.value as typeof theme)}
            className="h-10 w-full rounded-md border border-neutral-300 bg-white px-3 text-sm dark:border-neutral-700 dark:bg-neutral-900"
          >
            <option value="system">System</option>
            <option value="light">Light</option>
            <option value="dark">Dark</option>
          </select>
        </div>

        <div>
          <label htmlFor="settings-sort" className="mb-1 block text-sm font-medium">
            Default sort
          </label>
          <select
            id="settings-sort"
            value={sort}
            onChange={(e) => setSort(e.target.value as typeof sort)}
            className="h-10 w-full rounded-md border border-neutral-300 bg-white px-3 text-sm dark:border-neutral-700 dark:bg-neutral-900"
          >
            <option value="recently-updated">Recently updated</option>
            <option value="recently-created">Recently created</option>
            <option value="alphabetical">Alphabetical</option>
            <option value="most-copied">Most frequently copied</option>
          </select>
        </div>

        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={confirmDelete}
            onChange={(e) => setConfirmDelete(e.target.checked)}
            className="h-4 w-4 rounded border-neutral-300 accent-accent-600"
          />
          Confirm before deleting
        </label>

        <div className="flex justify-end gap-2 pt-2">
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button variant="primary" onClick={handleSave}>
            Save
          </Button>
        </div>
      </div>
      <div className="mt-6 border-t border-neutral-200 pt-4 dark:border-neutral-800">
        <ImportExportPanel />
      </div>
    </Dialog>
  );
}