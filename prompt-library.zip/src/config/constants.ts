export const SYSTEM_FOLDER_ID = 'unfiled';
export const SYSTEM_FOLDER_NAME = 'Unfiled';
export const DB_NAME = 'prompt-library';
export const DB_VERSION = 1;
export const SETTINGS_KEY = 'app-settings';