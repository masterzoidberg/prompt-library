import { describe, it, expect, beforeEach } from 'vitest';
import 'fake-indexeddb/auto';
import { getDb, resetDbCache } from './db';
import { DB_NAME } from '../config/constants';
import { ensureSeeded } from './db';
import * as folderRepo from './folderRepository';
import * as tagRepo from './tagRepository';
import * as promptRepo from './promptRepository';

async function resetAll() {
  await resetDbCache();
  const db = await getDb();
  await db.clear('prompts');
  await db.clear('folders');
  await db.clear('tags');
  await db.clear('settings');
  await ensureSeeded();
}

describe('folderRepo', () => {
  beforeEach(resetAll);

  it('seeds the Unfiled folder', async () => {
    const folders = await folderRepo.listFolders();
    expect(folders).toHaveLength(1);
    expect(folders[0].name).toBe('Unfiled');
  });

  it('creates a folder', async () => {
    const f = await folderRepo.createFolder({ name: 'Writing' });
    expect(f.id).toBeDefined();
    expect(f.normalizedName).toBe('writing');
  });

  it('rejects duplicate name case-insensitively', async () => {
    await folderRepo.createFolder({ name: 'Writing' });
    await expect(folderRepo.createFolder({ name: '  WRITING ' })).rejects.toBeInstanceOf(
      folderRepo.FolderNameConflictError,
    );
  });

  it('refuses to rename Unfiled', async () => {
    await expect(folderRepo.updateFolder('unfiled', { name: 'Foo' })).rejects.toBeInstanceOf(
      folderRepo.SystemFolderProtectedError,
    );
  });

  it('refuses to delete Unfiled', async () => {
    await expect(folderRepo.deleteFolder('unfiled')).rejects.toBeInstanceOf(
      folderRepo.SystemFolderProtectedError,
    );
  });

  it('deletes a folder and moves prompts to Unfiled', async () => {
    const f = await folderRepo.createFolder({ name: 'Tmp' });
    const p = await promptRepo.createPrompt({ title: 't', content: 'c', folderId: f.id });
    await folderRepo.deleteFolder(f.id);
    expect(await folderRepo.getFolder(f.id)).toBeUndefined();
    const updated = await promptRepo.getPrompt(p.id);
    expect(updated?.folderId).toBe('unfiled');
  });

  it('updates a folder name', async () => {
    const f = await folderRepo.createFolder({ name: 'Old' });
    const updated = await folderRepo.updateFolder(f.id, { name: 'New' });
    expect(updated.name).toBe('New');
    expect(updated.normalizedName).toBe('new');
  });
});

describe('tagRepo', () => {
  beforeEach(resetAll);

  it('creates and lists tags', async () => {
    await tagRepo.createTag({ name: 'code' });
    await tagRepo.createTag({ name: 'writing' });
    const tags = await tagRepo.listTags();
    expect(tags.map((t) => t.name).sort()).toEqual(['code', 'writing']);
  });

  it('rejects duplicate tag name case-insensitively', async () => {
    await tagRepo.createTag({ name: 'Code' });
    await expect(tagRepo.createTag({ name: 'CODE' })).rejects.toBeInstanceOf(
      tagRepo.TagNameConflictError,
    );
  });

  it('deletes a tag and removes its id from prompts', async () => {
    const t = await tagRepo.createTag({ name: 'x' });
    const p = await promptRepo.createPrompt({ title: 't', content: 'c', tagIds: [t.id] });
    await tagRepo.deleteTag(t.id);
    expect(await tagRepo.getTag(t.id)).toBeUndefined();
    const updated = await promptRepo.getPrompt(p.id);
    expect(updated?.tagIds).toEqual([]);
  });
});

describe('promptRepo', () => {
  beforeEach(resetAll);

  it('requires title and content', async () => {
    await expect(promptRepo.createPrompt({ title: '', content: 'c' })).rejects.toThrow();
    await expect(promptRepo.createPrompt({ title: 't', content: '' })).rejects.toThrow();
  });

  it('assigns to Unfiled by default', async () => {
    const p = await promptRepo.createPrompt({ title: 't', content: 'c' });
    expect(p.folderId).toBe('unfiled');
  });

  it('duplicates with reset counts and "Copy of" prefix', async () => {
    const p = await promptRepo.createPrompt({ title: 't', content: 'c' });
    await promptRepo.recordCopy(p.id);
    const dup = await promptRepo.duplicatePrompt(p.id);
    expect(dup.id).not.toBe(p.id);
    expect(dup.title).toBe('Copy of t');
    expect(dup.copyCount).toBe(0);
    expect(dup.lastCopiedAt).toBeNull();
  });

  it('recordCopy increments count and sets lastCopiedAt but not updatedAt', async () => {
    const p = await promptRepo.createPrompt({ title: 't', content: 'c' });
    const before = p.updatedAt;
    const after = await promptRepo.recordCopy(p.id);
    expect(after.copyCount).toBe(1);
    expect(after.lastCopiedAt).not.toBeNull();
    expect(after.updatedAt).toBe(before);
  });

  it('updatePrompt updates updatedAt', async () => {
    const p = await promptRepo.createPrompt({ title: 't', content: 'c' });
    const before = p.updatedAt;
    const updated = await promptRepo.updatePrompt(p.id, { title: 't2' });
    expect(updated.updatedAt).not.toBe(before);
  });

  it('deletePrompt removes a prompt', async () => {
    const p = await promptRepo.createPrompt({ title: 't', content: 'c' });
    await promptRepo.deletePrompt(p.id);
    expect(await promptRepo.getPrompt(p.id)).toBeUndefined();
  });
});

describe('db', () => {
  it('uses the expected db name', () => {
    expect(DB_NAME).toBe('prompt-library');
  });
});