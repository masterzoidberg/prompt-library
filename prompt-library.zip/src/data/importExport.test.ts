import { describe, it, expect, beforeEach } from 'vitest';
import 'fake-indexeddb/auto';
import {
  validateExport,
  exportLibrary,
  importLibrary,
  EXPORT_FORMAT,
  type ExportPayload,
} from './importExport';
import { ImportValidationError } from './importExport';
import { resetDbCache, getDb, ensureSeeded } from './db';
import * as promptRepo from './promptRepository';
import * as folderRepo from './folderRepository';
import * as tagRepo from './tagRepository';

function basePayload(): ExportPayload {
  return {
    format: EXPORT_FORMAT,
    version: 1,
    exportedAt: new Date().toISOString(),
    prompts: [],
    folders: [
      {
        id: 'unfiled',
        name: 'Unfiled',
        normalizedName: 'unfiled',
        createdAt: '2025-01-01T00:00:00.000Z',
        updatedAt: '2025-01-01T00:00:00.000Z',
      },
    ],
    tags: [],
    settings: {
      schemaVersion: 1,
      theme: 'system',
      defaultSort: 'recently-updated',
      viewMode: 'card',
      confirmBeforeDelete: true,
    },
  };
}

beforeEach(async () => {
  await resetDbCache();
  const db = await getDb();
  await db.clear('prompts');
  await db.clear('folders');
  await db.clear('tags');
  await db.clear('settings');
  await ensureSeeded();
});

describe('validateExport', () => {
  it('accepts a minimal valid payload', () => {
    const v = validateExport(basePayload());
    expect(v.folders).toHaveLength(1);
  });

  it('rejects unknown format', () => {
    const p = basePayload();
    (p as unknown as { format: string }).format = 'other';
    expect(() => validateExport(p)).toThrow(ImportValidationError);
  });

  it('rejects missing system folder', () => {
    const p = basePayload();
    p.folders = [];
    expect(() => validateExport(p)).toThrow(/unfiled/);
  });

  it('rejects prompt referencing unknown folder', () => {
    const p = basePayload();
    p.prompts = [
      {
        id: 'p1',
        title: 't',
        content: 'c',
        folderId: 'missing',
        tagIds: [],
        isFavorite: false,
        copyCount: 0,
        createdAt: '2025-01-01T00:00:00.000Z',
        updatedAt: '2025-01-01T00:00:00.000Z',
        lastCopiedAt: null,
      } as never,
    ];
    expect(() => validateExport(p)).toThrow(/folderId/);
  });

  it('rejects prompt referencing unknown tag', () => {
    const p = basePayload();
    p.prompts = [
      {
        id: 'p1',
        title: 't',
        content: 'c',
        folderId: 'unfiled',
        tagIds: ['nope'],
        isFavorite: false,
        copyCount: 0,
        createdAt: '2025-01-01T00:00:00.000Z',
        updatedAt: '2025-01-01T00:00:00.000Z',
        lastCopiedAt: null,
      } as never,
    ];
    expect(() => validateExport(p)).toThrow(/tag/);
  });
});

describe('exportLibrary / importLibrary', () => {
  it('round-trips prompts, folders, and tags', async () => {
    const folder = await folderRepo.createFolder({ name: 'Writing' });
    const tag = await tagRepo.createTag({ name: 'code' });
    const prompt = await promptRepo.createPrompt({
      title: 'Greeting',
      content: 'Hello',
      folderId: folder.id,
      tagIds: [tag.id],
    });

    const payload = await exportLibrary();
    expect(payload.prompts).toHaveLength(1);
    expect(payload.folders.map((f) => f.name).sort()).toEqual(['Unfiled', 'Writing']);
    expect(payload.tags).toHaveLength(1);

    // Clear DB and re-import
    await resetDbCache();
    const db = await getDb();
    await db.clear('prompts');
    await db.clear('folders');
    await db.clear('tags');
    await db.clear('settings');

    await importLibrary(payload);
    const prompts = await promptRepo.listPrompts();
    const folders = await folderRepo.listFolders();
    const tags = await tagRepo.listTags();
    expect(prompts).toHaveLength(1);
    expect(prompts[0].id).toBe(prompt.id);
    expect(folders.length).toBeGreaterThanOrEqual(2);
    expect(tags).toHaveLength(1);
  });

  it('rolls back on validation failure (no partial write)', async () => {
    const before = await exportLibrary();
    const bad = basePayload();
    bad.prompts = [
      {
        id: 'p1',
        title: 't',
        content: 'c',
        folderId: 'does-not-exist',
        tagIds: [],
        isFavorite: false,
        copyCount: 0,
        createdAt: '2025-01-01T00:00:00.000Z',
        updatedAt: '2025-01-01T00:00:00.000Z',
        lastCopiedAt: null,
      } as never,
    ];
    await expect(importLibrary(bad)).rejects.toBeInstanceOf(ImportValidationError);
    const after = await exportLibrary();
    expect(after.prompts).toEqual(before.prompts);
  });
});