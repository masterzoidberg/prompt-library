import type { Prompt, Folder, Tag, Settings } from '../types';
import { SYSTEM_FOLDER_ID, SYSTEM_FOLDER_NAME, SETTINGS_KEY, DB_VERSION } from '../config/constants';
import { DEFAULT_SETTINGS } from '../types/settings';
import { getDb } from './db';

export const EXPORT_FORMAT = 'prompt-library-backup';
export const EXPORT_VERSION = 1;

export interface ExportPayload {
  format: typeof EXPORT_FORMAT;
  version: number;
  exportedAt: string;
  prompts: Prompt[];
  folders: Folder[];
  tags: Tag[];
  settings: Settings;
}

export class ImportValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ImportValidationError';
  }
}

function isObject(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null && !Array.isArray(v);
}

function requireString(obj: Record<string, unknown>, key: string, path: string): string {
  const v = obj[key];
  if (typeof v !== 'string' || !v) {
    throw new ImportValidationError(`${path}.${key} must be a non-empty string`);
  }
  return v;
}

function optionalString(obj: Record<string, unknown>, key: string, path: string): string | undefined {
  const v = obj[key];
  if (v === undefined) return undefined;
  if (typeof v !== 'string') throw new ImportValidationError(`${path}.${key} must be a string`);
  return v;
}

function requireNumber(obj: Record<string, unknown>, key: string, path: string): number {
  const v = obj[key];
  if (typeof v !== 'number') throw new ImportValidationError(`${path}.${key} must be a number`);
  return v;
}

function requireBoolean(obj: Record<string, unknown>, key: string, path: string): boolean {
  const v = obj[key];
  if (typeof v !== 'boolean') throw new ImportValidationError(`${path}.${key} must be a boolean`);
  return v;
}

function requireArray(obj: Record<string, unknown>, key: string, path: string): unknown[] {
  const v = obj[key];
  if (!Array.isArray(v)) throw new ImportValidationError(`${path}.${key} must be an array`);
  return v;
}

function validatePrompt(obj: Record<string, unknown>, path: string, folderIds: Set<string>, tagIds: Set<string>): Prompt {
  const id = requireString(obj, 'id', path);
  if (folderIds && !folderIds.has(requireString(obj, 'folderId', path))) {
    throw new ImportValidationError(`${path}.folderId does not reference a known folder`);
  }
  const tagIdsArr = requireArray(obj, 'tagIds', path);
  for (const t of tagIdsArr) {
    if (typeof t !== 'string' || !tagIds.has(t)) {
      throw new ImportValidationError(`${path}.tagIds contains unknown tag`);
    }
  }
  return {
    id,
    title: requireString(obj, 'title', path),
    content: requireString(obj, 'content', path),
    description: optionalString(obj, 'description', path),
    folderId: requireString(obj, 'folderId', path),
    tagIds: tagIdsArr as string[],
    isFavorite: requireBoolean(obj, 'isFavorite', path),
    copyCount: requireNumber(obj, 'copyCount', path),
    createdAt: requireString(obj, 'createdAt', path),
    updatedAt: requireString(obj, 'updatedAt', path),
    lastCopiedAt: obj.lastCopiedAt === null ? null : requireString(obj, 'lastCopiedAt', path),
  };
}

function validateFolder(obj: Record<string, unknown>, path: string): Folder {
  return {
    id: requireString(obj, 'id', path),
    name: requireString(obj, 'name', path),
    normalizedName: requireString(obj, 'normalizedName', path),
    createdAt: requireString(obj, 'createdAt', path),
    updatedAt: requireString(obj, 'updatedAt', path),
  };
}

function validateTag(obj: Record<string, unknown>, path: string): Tag {
  return {
    id: requireString(obj, 'id', path),
    name: requireString(obj, 'name', path),
    normalizedName: requireString(obj, 'normalizedName', path),
    createdAt: requireString(obj, 'createdAt', path),
    updatedAt: requireString(obj, 'updatedAt', path),
  };
}

function validateSettings(obj: Record<string, unknown>, path: string): Settings {
  return {
    schemaVersion: requireNumber(obj, 'schemaVersion', path),
    theme: (['system', 'light', 'dark'] as const).find((t) => t === obj.theme)
      ? (obj.theme as Settings['theme'])
      : (() => {
          throw new ImportValidationError(`${path}.theme must be system|light|dark`);
        })(),
    defaultSort: (['recently-updated', 'recently-created', 'alphabetical', 'most-copied'] as const).find(
      (s) => s === obj.defaultSort,
    )
      ? (obj.defaultSort as Settings['defaultSort'])
      : (() => {
          throw new ImportValidationError(`${path}.defaultSort invalid`);
        })(),
    viewMode: 'card' as const,
    confirmBeforeDelete: requireBoolean(obj, 'confirmBeforeDelete', path),
  };
}

export function validateExport(raw: unknown): ExportPayload {
  if (!isObject(raw)) throw new ImportValidationError('Root must be an object');
  if (raw.format !== EXPORT_FORMAT)
    throw new ImportValidationError(`Invalid format: expected "${EXPORT_FORMAT}"`);
  if (typeof raw.version !== 'number') throw new ImportValidationError('Missing version');
  if (typeof raw.exportedAt !== 'string') throw new ImportValidationError('Missing exportedAt');

  const folderArr = requireArray(raw, 'folders', 'root');
  const tagArr = requireArray(raw, 'tags', 'root');
  const promptArr = requireArray(raw, 'prompts', 'root');

  const folders = folderArr.map((f, i) => {
    if (!isObject(f)) throw new ImportValidationError(`folders[${i}] must be an object`);
    return validateFolder(f, `folders[${i}]`);
  });
  const folderIds = new Set(folders.map((f) => f.id));
  if (!folderIds.has(SYSTEM_FOLDER_ID))
    throw new ImportValidationError(`Missing system folder "${SYSTEM_FOLDER_NAME}" (${SYSTEM_FOLDER_ID})`);

  const tags = tagArr.map((t, i) => {
    if (!isObject(t)) throw new ImportValidationError(`tags[${i}] must be an object`);
    return validateTag(t, `tags[${i}]`);
  });
  const tagIds = new Set(tags.map((t) => t.id));

  const prompts = promptArr.map((p, i) => {
    if (!isObject(p)) throw new ImportValidationError(`prompts[${i}] must be an object`);
    return validatePrompt(p, `prompts[${i}]`, folderIds, tagIds);
  });

  if (!isObject(raw.settings)) throw new ImportValidationError('Missing settings');
  const settings = validateSettings(raw.settings, 'settings');

  return {
    format: EXPORT_FORMAT,
    version: raw.version,
    exportedAt: raw.exportedAt,
    prompts,
    folders,
    tags,
    settings,
  };
}

export async function exportLibrary(): Promise<ExportPayload> {
  const db = await getDb();
  const [prompts, folders, tags] = await Promise.all([
    db.getAll('prompts'),
    db.getAll('folders'),
    db.getAll('tags'),
  ]);
  const settings = (await db.get('settings', SETTINGS_KEY)) ?? DEFAULT_SETTINGS;
  return {
    format: EXPORT_FORMAT,
    version: EXPORT_VERSION,
    exportedAt: new Date().toISOString(),
    prompts,
    folders,
    tags,
    settings,
  };
}

export function exportFilename(date: Date = new Date()): string {
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const dd = String(date.getDate()).padStart(2, '0');
  return `prompt-library-backup-${yyyy}-${mm}-${dd}.json`;
}

export async function importLibrary(payload: ExportPayload): Promise<void> {
  const validation = validateExport(payload);
  const db = await getDb();
  const tx = db.transaction(['prompts', 'folders', 'tags', 'settings'], 'readwrite');
  await tx.objectStore('prompts').clear();
  await tx.objectStore('folders').clear();
  await tx.objectStore('tags').clear();

  for (const p of validation.prompts) await tx.objectStore('prompts').put(p);
  for (const f of validation.folders) await tx.objectStore('folders').put(f);
  for (const t of validation.tags) await tx.objectStore('tags').put(t);
  await tx.objectStore('settings').put(validation.settings, SETTINGS_KEY);

  await tx.done;
}

export function downloadJson(payload: ExportPayload, filename: string): void {
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export const __test__ = { SYSTEM_FOLDER_ID, SYSTEM_FOLDER_NAME, DB_VERSION };