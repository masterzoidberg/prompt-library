import type { Prompt, PromptCreate, PromptUpdate } from '../types/prompt';
import { SYSTEM_FOLDER_ID } from '../config/constants';
import { newId } from '../utils/id';
import { nowIso } from '../utils/date';
import { getDb } from './db';

export class PromptNotFoundError extends Error {
  constructor(id: string) {
    super(`Prompt not found: ${id}`);
    this.name = 'PromptNotFoundError';
  }
}

export async function listPrompts(): Promise<Prompt[]> {
  const db = await getDb();
  return db.getAll('prompts');
}

export async function getPrompt(id: string): Promise<Prompt | undefined> {
  const db = await getDb();
  return db.get('prompts', id);
}

export async function createPrompt(input: PromptCreate): Promise<Prompt> {
  const title = input.title.trim();
  const content = input.content;
  if (!title) throw new Error('Prompt title is required');
  if (!content) throw new Error('Prompt content is required');
  const now = nowIso();
  const prompt: Prompt = {
    id: newId(),
    title,
    content,
    description: input.description?.trim() || undefined,
    folderId: input.folderId || SYSTEM_FOLDER_ID,
    tagIds: input.tagIds ?? [],
    isFavorite: input.isFavorite ?? false,
    copyCount: 0,
    createdAt: now,
    updatedAt: now,
    lastCopiedAt: null,
  };
  const db = await getDb();
  await db.add('prompts', prompt);
  return prompt;
}

export async function updatePrompt(id: string, patch: PromptUpdate): Promise<Prompt> {
  const db = await getDb();
  const tx = db.transaction('prompts', 'readwrite');
  const current = await tx.store.get(id);
  if (!current) {
    await tx.done.catch(() => {});
    throw new PromptNotFoundError(id);
  }
  const next: Prompt = { ...current, updatedAt: nowIso() };
  if (patch.title !== undefined) {
    const title = patch.title.trim();
    if (!title) throw new Error('Prompt title is required');
    next.title = title;
  }
  if (patch.content !== undefined) {
    if (!patch.content) throw new Error('Prompt content is required');
    next.content = patch.content;
  }
  if (patch.description !== undefined) {
    next.description = patch.description.trim() || undefined;
  }
  if (patch.folderId !== undefined) {
    next.folderId = patch.folderId || SYSTEM_FOLDER_ID;
  }
  if (patch.tagIds !== undefined) {
    next.tagIds = patch.tagIds;
  }
  if (patch.isFavorite !== undefined) {
    next.isFavorite = patch.isFavorite;
  }
  await tx.store.put(next);
  await tx.done;
  return next;
}

export async function deletePrompt(id: string): Promise<void> {
  const db = await getDb();
  await db.delete('prompts', id);
}

export async function duplicatePrompt(id: string): Promise<Prompt> {
  const db = await getDb();
  const tx = db.transaction('prompts', 'readwrite');
  const current = await tx.store.get(id);
  if (!current) {
    await tx.done.catch(() => {});
    throw new PromptNotFoundError(id);
  }
  const now = nowIso();
  const copy: Prompt = {
    ...current,
    id: newId(),
    title: `Copy of ${current.title}`,
    isFavorite: false,
    copyCount: 0,
    lastCopiedAt: null,
    createdAt: now,
    updatedAt: now,
  };
  await tx.store.add(copy);
  await tx.done;
  return copy;
}

export async function recordCopy(id: string): Promise<Prompt> {
  const db = await getDb();
  const tx = db.transaction('prompts', 'readwrite');
  const current = await tx.store.get(id);
  if (!current) {
    await tx.done.catch(() => {});
    throw new PromptNotFoundError(id);
  }
  const next: Prompt = {
    ...current,
    copyCount: current.copyCount + 1,
    lastCopiedAt: nowIso(),
  };
  await tx.store.put(next);
  await tx.done;
  return next;
}

export async function movePromptsToFolder(promptIds: string[], folderId: string): Promise<void> {
  const db = await getDb();
  const tx = db.transaction('prompts', 'readwrite');
  for (const id of promptIds) {
    const current = await tx.store.get(id);
    if (!current) continue;
    await tx.store.put({ ...current, folderId, updatedAt: nowIso() });
  }
  await tx.done;
}