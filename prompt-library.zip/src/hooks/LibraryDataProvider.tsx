import { useCallback, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import type { Prompt, Folder, Tag } from '../types';
import { LibraryDataContext, type LibraryDataState } from './libraryDataContext';
import * as promptRepo from '../data/promptRepository';
import * as folderRepo from '../data/folderRepository';
import * as tagRepo from '../data/tagRepository';

export function LibraryDataProvider({ children }: { children: ReactNode }) {
  const [prompts, setPrompts] = useState<Prompt[]>([]);
  const [folders, setFolders] = useState<Folder[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  const [loaded, setLoaded] = useState(false);

  const reload = useCallback(async () => {
    const [p, f, t] = await Promise.all([
      promptRepo.listPrompts(),
      folderRepo.listFolders(),
      tagRepo.listTags(),
    ]);
    setPrompts(p);
    setFolders(f);
    setTags(t);
    setLoaded(true);
  }, []);

  useEffect(() => {
    reload().catch(() => setLoaded(true));
  }, [reload]);

  const value = useMemo<LibraryDataState>(
    () => ({ prompts, folders, tags, loaded, reload }),
    [prompts, folders, tags, loaded, reload],
  );

  return <LibraryDataContext.Provider value={value}>{children}</LibraryDataContext.Provider>;
}