import React, { useEffect } from 'react';
import { describe, it, expect, beforeEach } from 'vitest';
import 'fake-indexeddb/auto';
import { render, act } from '@testing-library/react';
import { LibraryDataProvider } from './LibraryDataProvider';
import { useFolders } from './useFolders';
import { useLibraryData } from './useLibraryData';
import { resetDbCache, getDb, ensureSeeded } from '../data/db';

beforeEach(async () => {
  await resetDbCache();
  const db = await getDb();
  await db.clear('prompts');
  await db.clear('folders');
  await db.clear('tags');
  await db.clear('settings');
  await ensureSeeded();
});

function ContextConsumer({ onUpdate }: { onUpdate: (snap: ReturnType<typeof useLibraryData>) => void }) {
  const snap = useLibraryData();
  useEffect(() => {
    onUpdate(snap);
  });
  return null;
}

function FoldersConsumer({ onUpdate }: { onUpdate: (snap: ReturnType<typeof useFolders>) => void }) {
  const snap = useFolders();
  useEffect(() => {
    onUpdate(snap);
  });
  return null;
}

async function mount() {
  const ctxHistory: ReturnType<typeof useLibraryData>[] = [];
  const folderHistory: ReturnType<typeof useFolders>[] = [];

  render(
    <LibraryDataProvider>
      <ContextConsumer onUpdate={(s) => ctxHistory.push(s)} />
      <FoldersConsumer onUpdate={(s) => folderHistory.push(s)} />
    </LibraryDataProvider>,
  );

  await act(async () => {
    await new Promise((r) => setTimeout(r, 0));
  });

  return {
    latestCtx: () => ctxHistory[ctxHistory.length - 1],
    latestFolders: () => folderHistory[folderHistory.length - 1],
  };
}

describe('shared library data context', () => {
  it('creating a folder updates both a context consumer and a useFolders consumer', async () => {
    const { latestCtx, latestFolders } = await mount();

    await act(async () => {
      await latestFolders().create({ name: 'Brand new' });
    });

    expect(latestFolders().folders.map((f) => f.name)).toContain('Brand new');
    expect(latestCtx().folders.map((f) => f.name)).toContain('Brand new');
  });

  it('deleting a folder updates both consumers', async () => {
    const { latestCtx, latestFolders } = await mount();

    let createdId = '';
    await act(async () => {
      const f = await latestFolders().create({ name: 'Tmp' });
      createdId = f.id;
    });

    expect(latestCtx().folders.map((f) => f.id)).toContain(createdId);

    await act(async () => {
      await latestFolders().remove(createdId);
    });

    expect(latestFolders().folders.map((f) => f.id)).not.toContain(createdId);
    expect(latestCtx().folders.map((f) => f.id)).not.toContain(createdId);
  });

  it('the context is shared (same Provider instance) so reload triggers updates for all consumers', async () => {
    const { latestCtx, latestFolders } = await mount();
    const initialFoldersRef = latestFolders().folders;
    void initialFoldersRef;

    await act(async () => {
      await latestFolders().create({ name: 'Another' });
    });

    expect(latestCtx().folders).toBe(latestFolders().folders);
    expect(latestCtx().loaded).toBe(true);
  });
});