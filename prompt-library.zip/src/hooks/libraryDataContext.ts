import { createContext } from 'react';
import type { Prompt, Folder, Tag } from '../types';

export interface LibraryDataState {
  prompts: Prompt[];
  folders: Folder[];
  tags: Tag[];
  loaded: boolean;
  reload: () => Promise<void>;
}

export const LibraryDataContext = createContext<LibraryDataState | null>(null);