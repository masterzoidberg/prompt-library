import { useEffect, useRef } from 'react';
import type { RefObject } from 'react';

interface ShortcutHandlers {
  focusSearch: () => void;
}

export function useKeyboardShortcuts(handlers: ShortcutHandlers): RefObject<boolean> {
  const activeRef = useRef(true);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const isEditable =
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.isContentEditable);

      if (e.key === '/' && !isEditable) {
        e.preventDefault();
        handlers.focusSearch();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [handlers]);
  return activeRef;
}