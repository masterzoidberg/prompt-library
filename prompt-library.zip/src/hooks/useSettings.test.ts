import { describe, it, expect, beforeEach } from 'vitest';
import 'fake-indexeddb/auto';
import { renderHook, act, waitFor } from '@testing-library/react';
import { useSettings } from './useSettings';
import { resetDbCache, getDb, ensureSeeded } from '../data/db';

beforeEach(async () => {
  await resetDbCache();
  const db = await getDb();
  await db.clear('settings');
  await ensureSeeded();
});

describe('useSettings', () => {
  it('loads defaults', async () => {
    const { result } = renderHook(() => useSettings());
    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.settings?.theme).toBe('system');
  });

  it('updates settings', async () => {
    const { result } = renderHook(() => useSettings());
    await waitFor(() => expect(result.current.loading).toBe(false));
    await act(async () => {
      await result.current.update({ theme: 'dark' });
    });
    expect(result.current.settings?.theme).toBe('dark');
  });
});