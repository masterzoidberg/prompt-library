import { useCallback, useEffect, useState } from 'react';
import { getSettings, saveSettings } from '../data/settingsRepository';
import type { Settings } from '../types/settings';
import { DEFAULT_SETTINGS } from '../types/settings';

export function useSettings() {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    getSettings()
      .then((s) => {
        if (!cancelled) {
          setSettings(s);
          setLoading(false);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setSettings(DEFAULT_SETTINGS);
          setLoading(false);
        }
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const update = useCallback(async (patch: Partial<Settings>) => {
    const next = await saveSettings({ ...(settings ?? DEFAULT_SETTINGS), ...patch });
    setSettings(next);
    return next;
  }, [settings]);

  const reload = useCallback(async () => {
    const s = await getSettings();
    setSettings(s);
  }, []);

  return { settings, loading, update, reload };
}