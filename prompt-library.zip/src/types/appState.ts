export type View =
  | { kind: 'all' }
  | { kind: 'favorites' }
  | { kind: 'folder'; folderId: string }
  | { kind: 'tag'; tagId: string }
  | { kind: 'search'; query: string };

export type DialogKind =
  | { kind: 'none' }
  | { kind: 'new-prompt' }
  | { kind: 'edit-prompt'; promptId: string }
  | { kind: 'new-folder' }
  | { kind: 'rename-folder'; folderId: string }
  | { kind: 'delete-folder'; folderId: string }
  | { kind: 'new-tag' }
  | { kind: 'rename-tag'; tagId: string }
  | { kind: 'delete-tag'; tagId: string }
  | { kind: 'move-prompt'; promptId: string }
  | { kind: 'delete-prompt'; promptId: string }
  | { kind: 'settings' };

export interface AppState {
  view: View;
  dialog: DialogKind;
  selectedTagIds: string[];
  setView: (v: View) => void;
  setDialog: (d: DialogKind) => void;
  toggleTagFilter: (tagId: string) => void;
  clearTagFilters: () => void;
}