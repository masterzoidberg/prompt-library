export interface Prompt {
  id: string;
  title: string;
  content: string;
  description?: string;
  folderId: string;
  tagIds: string[];
  isFavorite: boolean;
  copyCount: number;
  createdAt: string;
  updatedAt: string;
  lastCopiedAt: string | null;
}

export type PromptCreate = Omit<
  Prompt,
  | 'id'
  | 'createdAt'
  | 'updatedAt'
  | 'lastCopiedAt'
  | 'copyCount'
  | 'isFavorite'
  | 'tagIds'
  | 'folderId'
> & {
  folderId?: string;
  isFavorite?: boolean;
  tagIds?: string[];
};

export type PromptUpdate = Partial<
  Omit<Prompt, 'id' | 'createdAt' | 'updatedAt'>
>;