export type Theme = 'system' | 'light' | 'dark';
export type SortKey = 'recently-updated' | 'recently-created' | 'alphabetical' | 'most-copied';
export type ViewMode = 'card';

export interface Settings {
  schemaVersion: number;
  theme: Theme;
  defaultSort: SortKey;
  viewMode: ViewMode;
  confirmBeforeDelete: boolean;
}

export const DEFAULT_SETTINGS: Settings = {
  schemaVersion: 1,
  theme: 'system',
  defaultSort: 'recently-updated',
  viewMode: 'card',
  confirmBeforeDelete: true,
};