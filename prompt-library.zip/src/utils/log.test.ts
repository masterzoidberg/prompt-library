import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { log } from './log';

describe('log', () => {
  let logSpy: ReturnType<typeof vi.spyOn>;
  let warnSpy: ReturnType<typeof vi.spyOn>;
  let errorSpy: ReturnType<typeof vi.spyOn>;

  beforeEach(() => {
    logSpy = vi.spyOn(console, 'log').mockImplementation(() => {});
    warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    errorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
  });
  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('redacts user-content keys', () => {
    log.info('test', { title: 'secret', content: 'leak', folderId: 'safe-id' });
    const call = logSpy.mock.calls[0];
    expect(JSON.stringify(call)).toContain('[redacted]');
    expect(JSON.stringify(call)).not.toContain('secret');
    expect(JSON.stringify(call)).not.toContain('leak');
  });

  it('routes warn and error', () => {
    log.warn('w');
    log.error('e');
    expect(warnSpy).toHaveBeenCalled();
    expect(errorSpy).toHaveBeenCalled();
  });
});