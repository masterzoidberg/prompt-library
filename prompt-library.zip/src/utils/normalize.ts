export function normalizeName(input: string): string {
  return input.trim().toLowerCase().replace(/\s+/g, ' ');
}

export function normalizeForCompare(input: string): string {
  return normalizeName(input);
}