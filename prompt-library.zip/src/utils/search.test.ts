import { describe, it, expect } from 'vitest';
import { searchPrompts } from './search';
import type { Prompt, Folder, Tag } from '../types';

const p = (overrides: Partial<Prompt>): Prompt => ({
  id: Math.random().toString(),
  title: 't',
  content: 'c',
  folderId: 'unfiled',
  tagIds: [],
  isFavorite: false,
  copyCount: 0,
  createdAt: '2025-01-01T00:00:00.000Z',
  updatedAt: '2025-01-01T00:00:00.000Z',
  lastCopiedAt: null,
  ...overrides,
});

const folders = new Map<string, Folder>([
  ['unfiled', { id: 'unfiled', name: 'Unfiled', normalizedName: 'unfiled', createdAt: '', updatedAt: '' }],
  ['f1', { id: 'f1', name: 'Writing', normalizedName: 'writing', createdAt: '', updatedAt: '' }],
]);

const tags = new Map<string, Tag>([
  ['t1', { id: 't1', name: 'code', normalizedName: 'code', createdAt: '', updatedAt: '' }],
]);

describe('searchPrompts', () => {
  const prompts: Prompt[] = [
    p({ id: '1', title: 'Hello', content: 'world' }),
    p({ id: '2', title: 'Foo', content: 'Hello there', folderId: 'f1' }),
    p({ id: '3', title: 'Bar', content: 'baz', tagIds: ['t1'] }),
  ];

  it('returns all when query is empty', () => {
    expect(searchPrompts(prompts, '', folders, tags)).toHaveLength(3);
  });

  it('matches title case-insensitively', () => {
    expect(searchPrompts(prompts, 'HELLO', folders, tags).map((p) => p.id)).toEqual(['1', '2']);
  });

  it('matches content', () => {
    expect(searchPrompts(prompts, 'baz', folders, tags).map((p) => p.id)).toEqual(['3']);
  });

  it('matches folder name', () => {
    expect(searchPrompts(prompts, 'writing', folders, tags).map((p) => p.id)).toEqual(['2']);
  });

  it('matches tag name', () => {
    expect(searchPrompts(prompts, 'code', folders, tags).map((p) => p.id)).toEqual(['3']);
  });
});