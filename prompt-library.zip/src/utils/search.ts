import type { Prompt, Folder, Tag } from '../types';

export function searchPrompts(
  prompts: Prompt[],
  query: string,
  folderMap: Map<string, Folder>,
  tagMap: Map<string, Tag>,
): Prompt[] {
  const q = query.trim().toLowerCase();
  if (!q) return prompts;
  return prompts.filter((p) => {
    if (p.title.toLowerCase().includes(q)) return true;
    if (p.content.toLowerCase().includes(q)) return true;
    if (p.description?.toLowerCase().includes(q)) return true;
    const folder = folderMap.get(p.folderId);
    if (folder && folder.name.toLowerCase().includes(q)) return true;
    for (const tid of p.tagIds) {
      const t = tagMap.get(tid);
      if (t && t.name.toLowerCase().includes(q)) return true;
    }
    return false;
  });
}